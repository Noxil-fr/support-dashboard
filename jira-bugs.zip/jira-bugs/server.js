const express = require('express');
const axios   = require('axios');
const cors    = require('cors');
const path    = require('path');

const app  = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Proxy vers l'API Jira
app.get('/api/bugs', async (req, res) => {
  const { domain, email, token, project } = req.query;

  if (!domain || !email || !token) {
    return res.status(400).json({ error: 'Paramètres manquants : domain, email, token.' });
  }

  let jql = 'issuetype = Bug ORDER BY created DESC';
  if (project) jql = `project = "${project}" AND issuetype = Bug ORDER BY created DESC`;

  const url = `https://${domain}/rest/api/3/search`;

  try {
    const response = await axios.get(url, {
      params: { jql, maxResults: 100, fields: 'summary,priority,status,reporter,assignee,created' },
      auth: { username: email, password: token },
      headers: { 'Accept': 'application/json' }
    });

    res.json(response.data);
  } catch (err) {
    const status  = err.response?.status || 500;
    const message = err.response?.data?.errorMessages?.[0] || err.message;
    res.status(status).json({ error: message });
  }
});

app.listen(PORT, () => {
  console.log(`✅ Serveur lancé sur http://localhost:${PORT}`);
});
